package com.simple.Apps.OnboardingUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnboardingUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
