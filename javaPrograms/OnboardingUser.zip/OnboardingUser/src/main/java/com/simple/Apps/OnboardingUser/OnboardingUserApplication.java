package com.simple.Apps.OnboardingUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnboardingUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnboardingUserApplication.class, args);
	}

}
